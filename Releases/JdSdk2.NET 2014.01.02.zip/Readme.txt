﻿JdSdk2
京东开放平台.NET版SDK
本SDK代码完全根据京东官方JavaSdk自动生成。API部分代码结构一致。 
所有Java Sdk中set get方法转换到.NET为属性，与类名称或子类名称同名的属性名称在前面加入下划线("_")以区分。

版本号规则变更为与编译发布日期一致。


交流QQ群：236361019 SDK交流

源码托管地址：
GitHub：https://github.com/starpeng/JdSdk2/
京东：https://code.jd.com/starpeng/JdSdk2.NET